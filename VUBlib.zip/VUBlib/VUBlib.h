/*
 * VUBlib.h
 *
 * Created: 26.6.2022. 14:26:45
 * Author : Goran
 */ 

#ifndef VUBlib_h
#define VUBlib_h
#include <Arduino.h>

//LED
#define redLed 8
#define yellowLed 9
#define greenLed 10
#define blueLed 11
//SERVO
#define servoPin 9
//LCD
#define rsPin 19
#define enPin 18
#define d4Pin 13
#define d5Pin 5
#define d6Pin 6
#define d7Pin 12
//Zujalica
#define buzzPin 17
//NTC
#define ntcPin 17
//Potenciometar
#define potPin 16
//LM35
#define lm35Pin 16
//Tipkala
#define button1 3
#define button2 2
#define button3 15
#define button4 14
//Rotancijski enkoder
#define pushButton 14
#define chA 3
#define chB 2
//Relej
#define relayPin 4
//HCSR04
#define trigPin 4
#define echoPin 4
//Numericki zaslon
#define siPin 13
#define sckPin 18
#define rckPin 19


#endif /* VUBlib_h */
